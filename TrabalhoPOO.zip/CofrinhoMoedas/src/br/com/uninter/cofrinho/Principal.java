package br.com.uninter.cofrinho;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Cofrinho cofrinho = new Cofrinho();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n=== MENU COFRINHO ===");
            System.out.println("1 - Adicionar Moeda");
            System.out.println("2 - Remover Moeda");
            System.out.println("3 - Listar Moedas");
            System.out.println("4 - Calcular Total");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            
            opcao = scanner.nextInt();
            
            switch (opcao) {
                case 1:
                    menuAdicionar(cofrinho, scanner);
                    break;
                case 2:
                    menuRemover(cofrinho, scanner);
                    break;
                case 3:
                    cofrinho.listarMoedas();
                    break;
                case 4:
                    double total = cofrinho.calcularTotal();
                    System.out.printf("Total em Reais: R$ %.2f%n", total);
                    break;
                case 0:
                    System.out.println("Encerrando programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
        
        scanner.close();
    }

    private static void menuAdicionar(Cofrinho cofrinho, Scanner scanner) {
        System.out.println("\n--- ADICIONAR MOEDA ---");
        System.out.println("1 - Dólar");
        System.out.println("2 - Euro");
        System.out.println("3 - Yuan");
        System.out.println("4 - Yene");
        System.out.println("5 - Libra");
        System.out.print("Qual moeda? ");
        
        int tipo = scanner.nextInt();
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        
        Moeda moeda = null;
        switch (tipo) {
            case 1: moeda = new Dolar(valor); break;
            case 2: moeda = new Euro(valor); break;
            case 3: moeda = new Yuan(valor); break;
            case 4: moeda = new Yene(valor); break;
            case 5: moeda = new Libra(valor); break;
            default: System.out.println("Tipo inválido!");
        }
        
        if (moeda != null) {
            cofrinho.adicionarMoeda(moeda);
        }
    }

    private static void menuRemover(Cofrinho cofrinho, Scanner scanner) {
        System.out.println("\n--- REMOVER MOEDA ---");
        System.out.println("1 - Dólar");
        System.out.println("2 - Euro");
        System.out.println("3 - Yuan");
        System.out.println("4 - Yene");
        System.out.println("5 - Libra");
        System.out.print("Qual moeda? ");
        
        int tipo = scanner.nextInt();
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        
        Moeda moeda = null;
        switch (tipo) {
            case 1: moeda = new Dolar(valor); break;
            case 2: moeda = new Euro(valor); break;
            case 3: moeda = new Yuan(valor); break;
            case 4: moeda = new Yene(valor); break;
            case 5: moeda = new Libra(valor); break;
            default: System.out.println("Tipo inválido!");
        }
        
        if (moeda != null) {
            cofrinho.removerMoeda(moeda);
        }
    }
}