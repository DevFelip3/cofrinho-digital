package br.com.uninter.cofrinho;

// Classe para moeda Yuan
public class Yuan extends Moeda {
    private static final double TAXA = 0.75; // 1 yuan = 0.75 reais

    public Yuan(double valor) {
        super(valor, "Yuan");
    }

    // Converte yuan para real
    @Override
    public double converterParaReal() {
        return valor * TAXA;
    }
}