package br.com.uninter.cofrinho;

// Classe para moeda Yene
public class Yene extends Moeda {
    private static final double TAXA = 0.05; // 1 yene = 0.05 reais

    public Yene(double valor) {
        super(valor, "Yene");
    }

    // Converte yene para real
    @Override
    public double converterParaReal() {
        return valor * TAXA;
    }
}