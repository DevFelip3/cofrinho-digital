package br.com.uninter.cofrinho;

// Classe para moeda Libra
public class Libra extends Moeda {
    private static final double TAXA = 7.0; // 1 libra = 7 reais

    public Libra(double valor) {
        super(valor, "Libra");
    }

    // Converte libra para real
    @Override
    public double converterParaReal() {
        return valor * TAXA;
    }
}