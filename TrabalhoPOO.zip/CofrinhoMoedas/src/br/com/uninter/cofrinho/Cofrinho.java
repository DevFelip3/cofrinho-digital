package br.com.uninter.cofrinho;

import java.util.ArrayList;

public class Cofrinho {
    private ArrayList<Moeda> moedas = new ArrayList<>();

    public void adicionarMoeda(Moeda moeda) {
        if (moeda == null) {
            System.out.println("Erro: Moeda não pode ser nula");
            return;
        }
        moedas.add(moeda);
        System.out.println("Moeda adicionada: " + moeda);
    }

    public boolean removerMoeda(Moeda moeda) {
        if (moedas.remove(moeda)) {
            System.out.println("Moeda removida: " + moeda);
            return true;
        }
        System.out.println("Moeda não encontrada: " + moeda);
        return false;
    }

    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio!");
            return;
        }
        System.out.println("Moedas no cofrinho:");
        for (Moeda moeda : moedas) {
            System.out.println(moeda);
        }
    }

    public double calcularTotal() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio - total: R$ 0.00");
            return 0;
        }
        double total = 0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();
        }
        return total;
    }
}