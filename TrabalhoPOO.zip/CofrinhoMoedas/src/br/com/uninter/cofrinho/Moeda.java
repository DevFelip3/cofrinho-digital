package br.com.uninter.cofrinho;

// Classe base para todas as moedas
public abstract class Moeda {
    protected double valor;  // Valor da moeda
    protected String pais;   // País de origem

    public Moeda(double valor, String pais) {
        this.valor = valor;
        this.pais = pais;
    }

    // Método que todas as moedas devem implementar
    public abstract double converterParaReal();

    // Compara se duas moedas são iguais
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Moeda moeda = (Moeda) obj;
        return Double.compare(moeda.valor, valor) == 0 && pais.equals(moeda.pais);
    }

    // Representação textual da moeda
    @Override
    public String toString() {
        return pais + " - " + valor;
    }
}