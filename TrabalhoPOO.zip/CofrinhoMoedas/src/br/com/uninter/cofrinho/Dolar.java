package br.com.uninter.cofrinho;

// Classe para moeda Dólar
public class Dolar extends Moeda {
    private static final double TAXA = 5.0; // 1 dólar = 5 reais

    public Dolar(double valor) {
        super(valor, "Dólar");
    }

    // Converte dólar para real
    @Override
    public double converterParaReal() {
        return valor * TAXA;
    }
}