package br.com.uninter.cofrinho;

// Classe para moeda Euro
public class Euro extends Moeda {
    private static final double TAXA = 6.0; // 1 euro = 6 reais

    public Euro(double valor) {
        super(valor, "Euro");
    }

    // Converte euro para real
    @Override
    public double converterParaReal() {
        return valor * TAXA;
    }
}